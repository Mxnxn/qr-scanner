import React from "react";
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Platform,
	TouchableNativeFeedback,
} from "react-native";
import Colors from "../constants/Colors";
const GridTile = (props) => {
	let ClickComponent = TouchableOpacity;

	if (Platform.OS === "android" && Platform.Version > 21) {
		ClickComponent = TouchableNativeFeedback;
	}
	return (
		<View
			style={{
				flex: 1,
				height: 150,
				margin: 14,
				borderRadius: 18,
				overflow: "hidden",
			}}
		>
			<ClickComponent
				activeOpacity={0.76}
				style={{ flex: 1 }}
				onPress={() => {
					//! detail method
					//? props.navigation.navigate({
					//?		routeName: "CategoryMeal",
					//? 	params: {
					//? 		title: itemData.item.title,
					//? 	},
					//? });
					//! short syntax
					props.navigation.navigate("CategoryMeal", {
						id: props.itemData.item.id,
					});
				}}
			>
				<View
					style={{
						flex: 1,
						...style.gridItem,
						...{ backgroundColor: props.itemData.item.color },
					}}
				>
					<Text
						style={{ color: Colors.white, fontSize: 20, fontFamily: "GEB" }}
					>
						{props.itemData.item.title}
					</Text>
				</View>
			</ClickComponent>
		</View>
	);
};
const style = StyleSheet.create({
	gridItem: {
		overflow: "hidden",
		height: 150,
		borderRadius: 18,
		shadowOffset: { width: 0, height: 0 },
		shadowRadius: 5,
		shadowOpacity: 0.26,
		elevation: 3,
		alignItems: "center",
		justifyContent: "center",
	},
});

export default GridTile;
