import React, { useState, useEffect, useCallback } from "react";

import { View, Text, StyleSheet, Switch } from "react-native";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import HeaderButton from "../components/HeaderButton";
import Colors from "../constants/Colors";
import { useSelector, useDispatch } from "react-redux";
import { setFilter } from "../store/actions/meals";
const FilterScreen = (props) => {
	const appliedFilters = useSelector((state) => state.meals.filterSettings);
	const [isGlutenFree, setGlutenFree] = useState(appliedFilters.glutenFree);
	const [isVegan, setIsVegan] = useState(appliedFilters.vegan);
	const [isVeg, setIsVeg] = useState(appliedFilters.veg);
	const [isLactosFree, setIsLactosFree] = useState(appliedFilters.lactosFree);
	const { navigation } = props;

	const dispatch = useDispatch();

	const saveFilters = useCallback(() => {
		const state = {
			glutenFree: isGlutenFree,
			vegan: isVegan,
			veg: isVeg,
			lactosFree: isLactosFree,
		};
		dispatch(setFilter(state));
	}, [isLactosFree, isVeg, isVegan, isGlutenFree, dispatch]);

	useEffect(() => {
		navigation.setParams({ save: saveFilters });
	}, [saveFilters]);

	return (
		<View style={{ ...style.screen }}>
			<Text style={style.heading}>Available Filters</Text>
			<View style={style.filterContainer}>
				<View style={style.row}>
					<View style={style.textWrapper}>
						<Text style={style.text}>Gluten Free</Text>
					</View>
					<Switch
						style={{ marginRight: 10 }}
						trackColor={Colors.purple}
						value={isGlutenFree}
						onValueChange={(e) => setGlutenFree(e)}
					/>
				</View>
				<View style={style.row}>
					<View style={style.textWrapper}>
						<Text style={style.text}>Vegan</Text>
					</View>
					<Switch
						style={{ marginRight: 10 }}
						trackColor={Colors.purple}
						value={isVegan}
						onValueChange={(e) => setIsVegan(e)}
					/>
				</View>
				<View style={style.row}>
					<View style={style.textWrapper}>
						<Text style={style.text}>Lactos Free</Text>
					</View>
					<Switch
						style={{ marginRight: 10 }}
						trackColor={Colors.purple}
						value={isLactosFree}
						onValueChange={(e) => setIsLactosFree(e)}
					/>
				</View>
				<View style={style.row}>
					<View style={style.textWrapper}>
						<Text style={style.text}>Vegetarian</Text>
					</View>
					<Switch
						style={{ marginRight: 10 }}
						trackColor={Colors.purple}
						value={isVeg}
						onValueChange={(e) => setIsVeg(e)}
					/>
				</View>
			</View>
		</View>
	);
};

const style = StyleSheet.create({
	screen: {
		flex: 1,
		marginTop: 15,
		marginLeft: 15,
	},
	heading: {
		fontFamily: "GEB",
		fontSize: 20,
	},
	filterContainer: {
		marginTop: 12,
		width: "95%",
	},
	row: {
		flexDirection: "row",
		marginVertical: 6,
		paddingVertical: 12,
		borderBottomWidth: 1,
		borderColor: "rgba(128,128,128,0.4)",
	},
	textWrapper: {
		flex: 1,

		justifyContent: "center",
	},
	text: {
		fontFamily: "GL",
		fontSize: 18,
	},
});

FilterScreen.navigationOptions = (nvData) => {
	return {
		headerLeft: () => (
			<HeaderButtons HeaderButtonComponent={HeaderButton}>
				<Item
					title="Menu"
					iconName="ios-menu"
					onPress={() => {
						nvData.navigation.toggleDrawer();
					}}
				/>
			</HeaderButtons>
		),
		headerRight: () => (
			<HeaderButtons HeaderButtonComponent={HeaderButton}>
				<Item
					title="Menu"
					iconName="ios-save"
					onPress={nvData.navigation.getParam("save")}
				/>
			</HeaderButtons>
		),
	};
};

export default FilterScreen;
