import React from "react";

import {
	View,
	Text,
	StyleSheet,
	Button,
	TouchableOpacity,
	FlatList,
} from "react-native";

import { HeaderButtons, Item } from "react-navigation-header-buttons";

import HeaderButton from "../components/HeaderButton";

import CategoryMeal from "./CategoryMeal";
import { CATEGORY } from "../data/dummy-data";
import GridTile from "../components/GridTile";
import Colors from "../constants/Colors";
import { ceil } from "react-native-reanimated";
const CategoryScreen = (props) => {
	const renderGridItems = (itemData) => {
		return <GridTile {...props} itemData={itemData} />;
	};

	return (
		<>
			<View
				style={{
					shadowOffset: { width: 2 },
					shadowOpacity: 0.2,
					shadowRadius: 2,
					shadowColor: Colors.white,
				}}
			>
				<Text
					style={{
						padding: 14,
						fontFamily: "GEB",
					}}
				>
					Menu:
				</Text>
			</View>
			<FlatList numColumns={2} data={CATEGORY} renderItem={renderGridItems} />
		</>
	);
};

CategoryScreen.navigationOptions = (navigationData) => {
	return {
		headerTitle: () => (
			<View style={{ justifyContent: "center" }}>
				<Text
					style={{
						fontFamily: "GEB",
						color: Colors.dark,
						fontSize: 24,
					}}
				>
					Meals
				</Text>
			</View>
		),
		headerLeft: () => (
			<HeaderButtons HeaderButtonComponent={HeaderButton}>
				<Item
					title="Menu"
					iconName="ios-menu"
					onPress={() => {
						navigationData.navigation.toggleDrawer();
					}}
				></Item>
			</HeaderButtons>
		),
	};
};

export default CategoryScreen;
