//! long {props.navigation.state.params.key}
//! short {props.navigation.getParam("key")}

import React from "react";

import { View, Text, StyleSheet } from "react-native";
import { CATEGORY } from "../data/dummy-data";
import Colors from "../constants/Colors";
import MealList from "../components/MealList";
import { useSelector } from "react-redux";

const CategoryMeal = (props) => {
	const availableMeals = useSelector((state) => state.meals.filterMeals);
	const extractedMeals = availableMeals.filter(
		(meal) => meal.cids.indexOf(props.navigation.getParam("id")) >= 0
	);

	if (extractedMeals.length === 0) {
		return (
			<View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
				<Text>It's empty. Check your filters</Text>
			</View>
		);
	}

	return <MealList listData={extractedMeals} navigation={props.navigation} />;
};

const style = StyleSheet.create({
	screen: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
	},
});

CategoryMeal.navigationOptions = (navigationData) => {
	const catId = navigationData.navigation.getParam("id");

	const selectedCategory = CATEGORY.find((cat) => cat.id === catId);
	return {
		headerTitle: selectedCategory.title,
		headerTintColor: Colors.bblue,
		headerStyle: {
			backgroundColor: Colors.white,
		},
	};
};

export default CategoryMeal;
