import React, { useReducer, isValidElement } from "react";
import {
	View,
	Text,
	TextInput,
	StyleSheet,
	KeyboardAvoidingView,
	ScrollView,
	TouchableOpacity,
} from "react-native";

const REDUCER_INPUT_UPDATE = "INPUT_UPDATE";
const formReducer = (state, action) => {
	if (action.type === REDUCER_INPUT_UPDATE) {
	}
};

const LoginScreen = (props) => {
	const [formStata, dispatchForm] = useReducer(formReducer, {
		inputValues: {
			name: "",
			email: "",
			password: "",
			phone: "",
		},
		inputValidator: {
			name: false,
			email: false,
			password: false,
			phone: false,
		},
		isFormValid: false,
	});

	const nameChange = (text) => {
		let valid = false;
		if (text.trim().length > 0) {
			valid = true;
		}
		dispatchForm;
	};

	return (
		<KeyboardAvoidingView
			style={{ height: "100%", alignItems: "center", justifyContent: "center" }}
		>
			<ScrollView>
				<View style={{ flex: 1 }}>
					<View style={style.formGroup}>
						<Text> Name</Text>
						<TextInput style={style.inputF} />
					</View>
					<View style={style.formGroup}>
						<Text> Email</Text>
						<TextInput style={style.inputF} />
					</View>
					<View style={style.formGroup}>
						<Text> Password</Text>
						<TextInput style={style.inputF} />
					</View>
					<View style={style.formGroup}>
						<Text> Phone</Text>
						<TextInput style={style.inputF} />
					</View>
					<TouchableOpacity>
						<View style={style.button}>
							<Text
								style={{
									color: "#ffffff",
								}}
							>
								Login
							</Text>
						</View>
					</TouchableOpacity>
				</View>
			</ScrollView>
		</KeyboardAvoidingView>
	);
};

const style = StyleSheet.create({
	inputF: {
		height: 40,
		fontSize: 20,
		width: 200,
		borderBottomWidth: 1,
	},
	formGroup: {
		marginVertical: 10,
	},
	button: {
		height: 50,
		width: 200,
		backgroundColor: "#3f3f3f",
	},
});

export default LoginScreen;
