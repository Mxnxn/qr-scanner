import React from "react";

import { View, Text, StyleSheet } from "react-native";
import MealList from "../components/MealList";
import { MEALS } from "../data/dummy-data";
import Colors from "../constants/Colors";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import HeaderButton from "../components/HeaderButton";
import { useSelector } from "react-redux";
const FavouriteScreen = (props) => {
	const favMeals = useSelector((state) => state.meals.favMeals);

	return favMeals.length ? (
		<MealList listData={favMeals} navigation={props.navigation} />
	) : (
		<View
			style={{
				flex: 1,
				alignItems: "center",
				justifyContent: "center",
			}}
		>
			<Text style={{}}>It's empty</Text>
		</View>
	);
};

const style = StyleSheet.create({
	screen: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
	},
});

FavouriteScreen.navigationOptions = (navigationData) => {
	return {
		headerTitle: () => (
			<Text style={{ fontFamily: "GEB", color: Colors.purple, fontSize: 23 }}>
				Favourites
			</Text>
		),
		headerLeft: () => (
			<HeaderButtons HeaderButtonComponent={HeaderButton}>
				<Item
					title="Menu"
					iconName="ios-menu"
					onPress={() => {
						navigationData.navigation.toggleDrawer();
					}}
				/>
			</HeaderButtons>
		),
	};
};

export default FavouriteScreen;
