import React, { useEffect, useCallback } from "react";

import { View, Text, StyleSheet, Image } from "react-native";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import HeaderButton from "../components/HeaderButton";
import Colors from "../constants/Colors";
import { ScrollView } from "react-native-gesture-handler";
import { useSelector, useDispatch } from "react-redux";
import { toggleFavourite } from "../store/actions/meals";
const MealDetailScreen = (props) => {
	const availableMeals = useSelector((state) => state.meals.meals);
	const mealId = props.navigation.getParam("meal_id");
	const selectedMeal = availableMeals.find((meal) => meal.id === mealId);

	//! to check if meal is exist in fav or not
	const favMeals = useSelector((state) =>
		state.meals.favMeals.some((meal) => meal.id === mealId)
	);

	useEffect(() => {
		//! not optimal send data for navOptions
		//props.navigation.setParams({ mealTitle: selectedMeal.title });
		props.navigation.setParams({ toggle: toggleFav });
	}, [toggleFav]);
	const dispatch = useDispatch();

	useEffect(() => {
		props.navigation.setParams({ bool: favMeals });
	}, [favMeals]);

	const toggleFav = useCallback(() => {
		dispatch(toggleFavourite(mealId));
	}, [dispatch, mealId]);

	return (
		<ScrollView>
			<View style={{ ...style.screen }}>
				<Image
					source={{ uri: selectedMeal.imageurl }}
					style={{
						width: "100%",
						height: 250,
						borderBottomLeftRadius: 24,
						borderBottomRightRadius: 24,
					}}
				/>
				<View style={style.headingWrapper}>
					<Text style={style.heading}>Indegredients</Text>
				</View>
				{selectedMeal.indigredients.map((indg, index) => (
					<View key={index} style={style.wrapper}>
						<Text style={style.dataRow}>{indg}</Text>
					</View>
				))}
				<View style={style.headingWrapper}>
					<Text style={style.heading}>Recipe</Text>
				</View>
				{selectedMeal.steps.map((indg, index) => (
					<View key={index} style={style.wrapper}>
						<Text style={style.dataRow}>{indg}</Text>
					</View>
				))}
			</View>
		</ScrollView>
	);
};

const style = StyleSheet.create({
	screen: {
		flex: 1,
		justifyContent: "center",
		alignItems: "center",
	},
	heading: {
		fontSize: 23,
		marginVertical: 8,
		fontFamily: "GEB",
	},
	dataRow: {
		fontFamily: "AB",
		marginVertical: 8,
		paddingHorizontal: 12,
	},
	wrapper: {
		width: "90%",
		borderRadius: 8,
		borderWidth: 1,
		marginVertical: 5,
		borderColor: Colors.bblue,
	},
	headingWrapper: {
		alignItems: "flex-start",
		width: "90%",
		justifyContent: "center",
	},
});

MealDetailScreen.navigationOptions = (navigationData) => {
	//! to get
	// const title = navigationData.navigation.getParam("mealTitle");
	const toggleFunc = navigationData.navigation.getParam("toggle");
	const bool = navigationData.navigation.getParam("bool");

	return {
		headerTitle: () => (
			<Text style={{ fontFamily: "GEB", fontSize: 23, color: Colors.purple }}>
				Detail
			</Text>
		),
		headerRight: () => (
			<HeaderButtons HeaderButtonComponent={HeaderButton}>
				<Item
					title="fav"
					iconName={bool ? "ios-star" : "ios-star-outline"}
					onPress={toggleFunc}
				></Item>
			</HeaderButtons>
		),
	};
};

export default MealDetailScreen;
