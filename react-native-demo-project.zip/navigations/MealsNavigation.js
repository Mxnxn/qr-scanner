import React from "react";
import { createAppContainer } from "react-navigation";
import { createStackNavigator } from "react-navigation-stack";
import { createDrawerNavigator } from "react-navigation-drawer";

import { Ionicons, AntDesign } from "@expo/vector-icons";
import { createBottomTabNavigator } from "react-navigation-tabs";

import { createMaterialBottomTabNavigator } from "react-navigation-material-bottom-tabs";

import CategoryScreen from "../screens/CategoryScreen";
import CategoryMeal from "../screens/CategoryMeal";
import FavouriteMeal from "../screens/FavouriteMeal";
import MealDetailScreen from "../screens/MealDetailScreen";
import FilterScreen from "../screens/FilterScreen";
import LoginScreen from "../screens/Login";
import Colors from "../constants/Colors";
import { Platform } from "react-native";

const MealsNavigator = createStackNavigator({
	Category: CategoryScreen,
	CategoryMeal: CategoryMeal,
	MealDetail: MealDetailScreen,
});

const FavStackNavigator = createStackNavigator({
	Favourites: FavouriteMeal,
	MealDetail: MealDetailScreen,
});

const tabConfig = {
	Meals: {
		screen: MealsNavigator,
		navigationOptions: {
			tabBarColor: Colors.purple,
			tabBarIcon: (tabInfo) => {
				return (
					<Ionicons name="ios-restaurant" size={24} color={tabInfo.tintColor} />
				);
			},
		},
	},
	FavMeals: {
		screen: FavStackNavigator,
		navigationOptions: {
			tabBarColor: Colors.danger,
			tabBarIcon: (tabInfo) => {
				return <AntDesign name="star" size={25} color={tabInfo.tintColor} />;
			},
		},
	},
};

const MealFavNavTabNavigator =
	Platform.OS === "android"
		? createMaterialBottomTabNavigator(tabConfig, {
				activeTintColor: Colors.white,
				shifting: true,
		  })
		: createBottomTabNavigator(tabConfig, {
				tabBarOptions: {
					activeTintColor: Colors.purple,
				},
		  });
const FilterNavigator = createStackNavigator({
	Filters: FilterScreen,
});
const LoginNavigator = createStackNavigator({
	Login: LoginScreen,
});
const MainNavigator = createDrawerNavigator({
	MealsFav: MealFavNavTabNavigator,
	FilterScreen: FilterNavigator,
	Login: LoginNavigator,
});

export default createAppContainer(MainNavigator);
