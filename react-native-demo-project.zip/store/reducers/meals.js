import { MEALS } from "../../data/dummy-data";
import { TOGGLE_FAVOURITE, SET_FILTER } from "../actions/meals";

const initialState = {
	meals: MEALS,
	filterMeals: MEALS,
	favMeals: [],
	filterSettings: {
		glutenFree: false,
		vegan: false,
		veg: false,
		lactosFree: false,
	},
};

const mealsReducers = (state = initialState, action) => {
	switch (action.type) {
		case TOGGLE_FAVOURITE:
			const existingIndex = state.favMeals.findIndex(
				(meal) => meal.id === action.mealId
			);
			if (existingIndex >= 0) {
				const updatedNewFav = [...state.favMeals];
				updatedNewFav.splice(existingIndex, 1);
				return { ...state, favMeals: updatedNewFav };
			} else {
				const meal = state.meals.find((meal) => meal.id === action.mealId);
				return { ...state, favMeals: state.favMeals.concat(meal) };
			}
		case SET_FILTER:
			const appliedFilters = action.filters;

			const updateFilterMeals = state.meals.filter((meal) => {
				if (appliedFilters.glutenFree && !meal.isGlutenFree) return false;
				if (appliedFilters.veg && !meal.isVeg) return false;
				if (appliedFilters.vegan && !meal.isVegan) return false;
				if (appliedFilters.lactosFree && !meal.isLactosFree) return false;
				return true;
			});
			return {
				...state,
				filterMeals: updateFilterMeals,
				filterSettings: action.filters,
			};
		default:
			return state;
	}
};

export default mealsReducers;
